CREATE PROCEDURE selectApartment(IN dist VARCHAR(20), IN adrs VARCHAR(30), IN sq DOUBLE, IN rm INT, IN prc DOUBLE)
  BEGIN
  SELECT * FROM apartments WHERE  District = EXISTS (SELECT District FROM apartments WHERE District=dist)
                          AND Address= EXISTS(SELECT Address FROM apartments WHERE Address=adrs)
                          AND Square= EXISTS(SELECT Square FROM apartments WHERE Square=sq)
                          AND Room = EXISTS(SELECT Room FROM apartments WHERE Room=rm)
                           AND Price= EXISTS(SELECT Price FROM apartments WHERE Price=prc) ;
END;
